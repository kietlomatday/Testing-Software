﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MathCore.bai1;

namespace MathCore.Tests.bai1
{
    [TestClass]
    public class PowerTests
    {
        [TestMethod]
        public void Test_Power_WhenExponentIsZero_ShouldReturnOne()
        {
            double x = 100.0;
            int n = 0;
            double expected = 1.0;
            double actual = Calculator.Power(x, n);
            Assert.AreEqual(expected, actual, "Sai rồi: Mũ 0 thì phải bằng 1");
        }


        [TestMethod]
        public void Test_Power_WhenExponentIsPositive_ShouldReturnCorrectResult()
        {
            double x = 2.0;
            int n = 3;
            double expected = 8.0;

            double actual = Calculator.Power(x, n);

            Assert.AreEqual(expected, actual, 0.0001, "Sai rồi: 2 mũ 3 phải bằng 8");
        }

        [TestMethod]
        public void Test_Power_WhenExponentIsNegative_ShouldReturnInverse()
        {
            double x = 2.0;
            int n = -2;
            double expected = 0.25;
            double actual = Calculator.Power(x, n);
            Assert.AreEqual(expected, actual, 0.0001, "Sai rồi: 2 mũ -2 phải bằng 0.25");
        }
    }
}