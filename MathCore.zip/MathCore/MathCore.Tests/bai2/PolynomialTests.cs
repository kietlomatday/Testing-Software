﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using MathCore.bai2;

namespace MathCore.Tests.bai2
{
    [TestClass]
    public class PolynomialTests
    {
        [TestMethod]
        public void Test_Cal_ValidInput_ReturnsCorrectValue()
        {
            int n = 2;
            List<int> coefficients = new List<int> { 1, 2, 3 };
            double x = 2.0;
            int expected = 17;

            Polynomial poly = new Polynomial(n, coefficients);
            int actual = poly.Cal(x);

            Assert.AreEqual(expected, actual, "P(2) của 1+2x+3x^2 phải bằng 17");
        }

        [TestMethod]
        public void Test_Constructor_NotEnoughCoefficients_ThrowsException()
        {
            int n = 2;
            List<int> coefficients = new List<int> { 1, 2 };

            try
            {
                Polynomial poly = new Polynomial(n, coefficients);

                Assert.Fail("Lẽ ra phải có lỗi ArgumentException ném ra, nhưng lại không thấy gì.");
            }
            catch (ArgumentException)
            {
            }
            catch (Exception ex)
            {
                Assert.Fail("Ra lỗi nhưng sai loại. Mong đợi ArgumentException, nhận được: " + ex.GetType().Name);
            }
        }

        [TestMethod]
        public void Test_Constructor_NegativeN_ThrowsException()
        {
            int n = -1;
            List<int> coefficients = new List<int>();

            try
            {
                // Act
                Polynomial poly = new Polynomial(n, coefficients);

                Assert.Fail("Lẽ ra phải có lỗi khi nhập n âm.");
            }
            catch (ArgumentException)
            {
            }
            catch (Exception ex)
            {
                Assert.Fail("Ra lỗi nhưng sai loại. Mong đợi ArgumentException, nhận được: " + ex.GetType().Name);
            }
        }
    }
}