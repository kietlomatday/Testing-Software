﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using MathCore.bai3;

namespace MathCore.Tests.bai3
{
    [TestClass]
    public class RadixTests
    {
        [TestMethod]
        public void Test_Convert_DecimalToBinary_Correct()
        {
            int number = 10;
            Radix r = new Radix(number);
            string expected = "1010";
            string actual = r.ConvertDecimalToAnother(2);
            Assert.AreEqual(expected, actual, "10 chuyển sang nhị phân phải là 1010");
        }

        [TestMethod]
        public void Test_Convert_DecimalToHex_Correct()
        {
            int number = 255;
            Radix r = new Radix(number);
            string expected = "FF";

            string actual = r.ConvertDecimalToAnother(16);

            Assert.AreEqual(expected, actual, "255 chuyển sang Hex phải là FF");
        }

        [TestMethod]
        public void Test_Constructor_NegativeNumber_ThrowsException()
        {
            try
            {
                Radix r = new Radix(-5);
                Assert.Fail("Lẽ ra phải báo lỗi Incorrect Value");
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Incorrect Value", ex.Message);
            }
            catch (Exception)
            {
                Assert.Fail("Sai loại lỗi.");
            }
        }

        [TestMethod]
        public void Test_Convert_InvalidRadix_ThrowsException()
        {
            try
            {
                Radix r = new Radix(100);
                r.ConvertDecimalToAnother(20);
                Assert.Fail("Lẽ ra phải báo lỗi Invalid Radix");
            }
            catch (ArgumentException ex)
            {
                Assert.AreEqual("Invalid Radix", ex.Message);
            }
            catch (Exception)
            {
                Assert.Fail("Sai loại lỗi.");
            }
        }
    }
}