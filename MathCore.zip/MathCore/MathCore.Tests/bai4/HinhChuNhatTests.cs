﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MathCore.bai4;

namespace MathCore.Tests.bai4
{
    [TestClass]
    public class HinhChuNhatTests
    {
        [TestMethod]
        public void Test_TinhDienTich_ValidInput_ReturnsCorrectArea()
        {
            Diem p1 = new Diem(0, 4);
            Diem p2 = new Diem(5, 0);
            HinhChuNhat hcn = new HinhChuNhat(p1, p2);

            double expected = 20.0;

            double actual = hcn.TinhDienTich();

            Assert.AreEqual(expected, actual, "Diện tích hình chữ nhật tính sai.");
        }

        [TestMethod]
        public void Test_KiemTraGiaoNhau_Intersect_ReturnsTrue()
        {
            HinhChuNhat hcn1 = new HinhChuNhat(new Diem(0, 10), new Diem(10, 0));
            HinhChuNhat hcn2 = new HinhChuNhat(new Diem(5, 5), new Diem(15, -5));

            bool result = hcn1.KiemTraGiaoNhau(hcn2);

            Assert.IsTrue(result, "Hai hình này lẽ ra phải giao nhau.");
        }

        [TestMethod]
        public void Test_KiemTraGiaoNhau_NotIntersect_ReturnsFalse()
        {

            HinhChuNhat hcn1 = new HinhChuNhat(new Diem(0, 10), new Diem(10, 0));
            HinhChuNhat hcn3 = new HinhChuNhat(new Diem(20, 20), new Diem(30, 10));

            bool result = hcn1.KiemTraGiaoNhau(hcn3);

            Assert.IsFalse(result, "Hai hình này nằm xa nhau, không thể giao nhau.");
        }
    }
}