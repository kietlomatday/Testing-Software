﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using MathCore.bai5;

namespace MathCore.Tests.bai5
{
    [TestClass]
    public class HocVienTests
    {
        // TC1: Kiểm tra người đủ điều kiện (Happy Case)
        // ĐTB = 9.0, không môn nào < 5 => True
        [TestMethod]
        public void Test_CheckHocBong_Valid_ReturnsTrue()
        {
            HocVien hv = new HocVien("HV01", "Nguyen Van A", 9.0, 9.0, 9.0);
            Assert.IsTrue(hv.CheckHocBong());
        }

        // TC2: Kiểm tra người trượt do ĐTB thấp
        // ĐTB = 7.0 => False
        [TestMethod]
        public void Test_CheckHocBong_LowAverage_ReturnsFalse()
        {
            HocVien hv = new HocVien("HV02", "Nguyen Van B", 7.0, 7.0, 7.0);
            Assert.IsFalse(hv.CheckHocBong());
        }

        // TC3: Kiểm tra người trượt do có môn bị điểm liệt (< 5)
        // ĐTB = (10 + 10 + 4) / 3 = 8.0 (Đủ ĐTB)
        // Nhưng có môn 4 điểm => False
        [TestMethod]
        public void Test_CheckHocBong_HasLowSubject_ReturnsFalse()
        {
            HocVien hv = new HocVien("HV03", "Nguyen Van C", 10.0, 10.0, 4.0);
            Assert.IsFalse(hv.CheckHocBong(), "ĐTB cao nhưng có môn < 5 thì vẫn phải trượt.");
        }

        // TC4: Kiểm tra chức năng lọc danh sách
        [TestMethod]
        public void Test_QuanLyHocVien_FilterScholarship()
        {
            // Arrange: Tạo danh sách 3 người
            QuanLyHocVien ql = new QuanLyHocVien();
            ql.ThemHocVien(new HocVien("1", "A", 9, 9, 9)); // Đậu
            ql.ThemHocVien(new HocVien("2", "B", 6, 6, 6)); // Trượt
            ql.ThemHocVien(new HocVien("3", "C", 10, 10, 4)); // Trượt (dính điểm liệt)

            // Act
            List<HocVien> danhSachDau = ql.TimDanhSachDatHocBong();

            // Assert: Chỉ có 1 người đậu
            Assert.AreEqual(1, danhSachDau.Count);
            Assert.AreEqual("A", danhSachDau[0].HoTen);
        }
    }
}