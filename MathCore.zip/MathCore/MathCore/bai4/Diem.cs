﻿namespace MathCore.bai4
{
    public class Diem
    {
        public double X { get; set; }
        public double Y { get; set; }

        public Diem(double x, double y)
        {
            this.X = x;
            this.Y = y;
        }
    }
}