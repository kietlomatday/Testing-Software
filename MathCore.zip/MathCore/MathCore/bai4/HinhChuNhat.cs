﻿using System;

namespace MathCore.bai4
{
    public class HinhChuNhat
    {
        public Diem TopLeft { get; set; }
        public Diem BottomRight { get; set; }

        public HinhChuNhat(Diem topLeft, Diem bottomRight)
        {
            this.TopLeft = topLeft;
            this.BottomRight = bottomRight;
        }

        public double TinhDienTich()
        {
            double width = Math.Abs(this.BottomRight.X - this.TopLeft.X);
            double height = Math.Abs(this.TopLeft.Y - this.BottomRight.Y);
            return width * height;
        }

        public bool KiemTraGiaoNhau(HinhChuNhat other)
        {
            double thisLeft = Math.Min(this.TopLeft.X, this.BottomRight.X);
            double thisRight = Math.Max(this.TopLeft.X, this.BottomRight.X);
            double thisTop = Math.Max(this.TopLeft.Y, this.BottomRight.Y);
            double thisBottom = Math.Min(this.TopLeft.Y, this.BottomRight.Y);

            double otherLeft = Math.Min(other.TopLeft.X, other.BottomRight.X);
            double otherRight = Math.Max(other.TopLeft.X, other.BottomRight.X);
            double otherTop = Math.Max(other.TopLeft.Y, other.BottomRight.Y);
            double otherBottom = Math.Min(other.TopLeft.Y, other.BottomRight.Y);

            bool isLeft = thisRight < otherLeft;
            bool isRight = thisLeft > otherRight;
            bool isBelow = thisTop < otherBottom;
            bool isAbove = thisBottom > otherTop;

            return !(isLeft || isRight || isBelow || isAbove);
        }
    }
}