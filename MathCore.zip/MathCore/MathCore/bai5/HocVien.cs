﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MathCore.bai5
{
    public class HocVien
    {
        public string MaSo { get; set; }
        public string HoTen { get; set; }
        public string QueQuan { get; set; }
        public double DiemToan { get; set; }
        public double DiemVan { get; set; }
        public double DiemAnh { get; set; }

        public HocVien(string maSo, string hoTen, double toan, double van, double anh)
        {
            this.MaSo = maSo;
            this.HoTen = hoTen;
            this.DiemToan = toan;
            this.DiemVan = van;
            this.DiemAnh = anh;
        }

        // Tính điểm trung bình
        public double DiemTrungBinh
        {
            get { return (DiemToan + DiemVan + DiemAnh) / 3.0; }
        }

        // Kiểm tra điều kiện học bổng
        // Điều kiện: ĐTB >= 8.0 VÀ Không môn nào < 5.0
        public bool CheckHocBong()
        {
            if (DiemTrungBinh >= 8.0)
            {
                if (DiemToan >= 5.0 && DiemVan >= 5.0 && DiemAnh >= 5.0)
                {
                    return true;
                }
            }
            return false;
        }
    }
}