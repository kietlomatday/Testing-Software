﻿using System.Collections.Generic;

namespace MathCore.bai5
{
    public class QuanLyHocVien
    {
        private List<HocVien> dsHocVien;

        public QuanLyHocVien()
        {
            dsHocVien = new List<HocVien>();
        }

        public void ThemHocVien(HocVien hv)
        {
            dsHocVien.Add(hv);
        }

        // Hàm trả về danh sách những người được học bổng
        public List<HocVien> TimDanhSachDatHocBong()
        {
            List<HocVien> result = new List<HocVien>();
            foreach (var hv in dsHocVien)
            {
                if (hv.CheckHocBong())
                {
                    result.Add(hv);
                }
            }
            return result;
        }
    }
}